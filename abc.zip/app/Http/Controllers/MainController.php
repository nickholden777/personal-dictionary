<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Http\Requests;

class MainController extends Controller
{
    public function index()
    {
    	return view('pages.index');
    }

    public function add(Request $request) 
    {

    }

    public function edit(Request $request) 
    {

    }

    public function del(Request $request) 
    {

    }

}
