<tr id="here_<?php echo e($word->id); ?>" class="line_<?php echo e($word->id); ?>">
	<td><?php echo e($word->field1); ?></td>
	<td class="text-right edit">
		<i class="glyphicon glyphicon-cog change" id="change_<?php echo e($word->id); ?>"></i>
		<i class="glyphicon glyphicon-trash delete" id="delete_<?php echo e($word->id); ?>"></i>
	</td>
	<td class="text-right"><?php echo e($word->field2); ?></td>
</tr>