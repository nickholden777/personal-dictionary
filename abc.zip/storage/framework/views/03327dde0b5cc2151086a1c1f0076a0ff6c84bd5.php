<?php $__env->startSection('content'); ?>

<div class="col-md-4 col-md-offset-4 enter">
	<h3><i class="glyphicon glyphicon-option-vertical"></i> Sign in</h3>
	<?php if($errors): ?>
		<p class="error"><?php echo e($errors->first()); ?></p>
	<?php endif; ?>
	<form action="<?php echo e(route('login')); ?>" method="POST">
		<?php echo e(csrf_field()); ?>

		<div class="form-group">
			<input type="email" name="email" required class="input2" placeholder="Your Email" value="<?php echo e(old('email')); ?>">
		</div>
		<div class="form-group clearfix">
			<input type="password" name="password" required class="input2" placeholder="Your password">
		</div>
		<div class="form-group clearfix">
			<button type="submit" class="btn2 btn2-primary pull-right"><i class="glyphicon glyphicon-check"></i> Enter</button>
		</div>
	</form>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('default', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>